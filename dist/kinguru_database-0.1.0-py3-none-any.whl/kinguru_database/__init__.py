# Conteúdo do arquivo meu_pacote/__init__.py
def minha_funcao():
    return "Olá do kinguru database!"