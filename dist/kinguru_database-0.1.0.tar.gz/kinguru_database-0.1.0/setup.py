from setuptools import setup

setup(
    name='kinguru_database',
    version='0.1.0',
    description='Crud  simplificado',
    author='Gleison de souza luiz',
    author_email='gleisonnanet@gmail.com',
    packages=['kinguru_database'],
)
